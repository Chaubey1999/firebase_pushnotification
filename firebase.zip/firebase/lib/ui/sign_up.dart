import 'package:firebase/ui/home_page.dart';
import 'package:firebase/ui/sign_up.dart';
import 'package:firebase/utils/utils.dart';
import 'package:firebase/widgets/primary_btn.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  @override
  void dispose(){
    super.dispose();
    _emailController.dispose();
    _passwordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: const Text("Sign in"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Form(
                key: _formKey,
                child: Column(
              children: [
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                      suffixIcon: Icon(Icons.email),
                      hintText: "Email"
                  ),
                  validator: (value){
                    if(value!.isEmpty){
                      return "Enter email";
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                      suffixIcon: Icon(Icons.visibility),
                      hintText: "Password"
                  ),
                  validator: (value){
                    if(value!.isEmpty){
                      return "Enter password";
                    }
                    return null;
                  },
                ),
              ],
            )),
            const SizedBox(height: 50,),
            PrimaryBtn(title: "Sign up", onTap: (){
              if(_formKey.currentState!.validate()){
                Utils.auth.createUserWithEmailAndPassword(email: _emailController.text, password: _passwordController.text).then((value) {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> const HomePage()));
                }).onError((error, stackTrace) {
                  Utils().showToast(error.toString());
                });
              }
            }),
          ],
        ),
      ),
    );
  }
}
