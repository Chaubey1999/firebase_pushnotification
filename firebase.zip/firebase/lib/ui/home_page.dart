import 'package:firebase/firebase_service/notification_service.dart';
import 'package:firebase/ui/sign_in.dart';
import 'package:firebase/utils/utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  NotificationService notificationService = NotificationService();
  @override
  void initState(){
    super.initState();
    notificationService.requestNotificationPermission();
    notificationService.firebaseInit(context);
    notificationService.getDeviceToken().then((value) {
      print(value.toString());
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("HomePage"),
        actions: [
          IconButton(onPressed: (){
            Utils.auth.signOut().then((value) {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>const SignInScreen()));
            }).onError((error, stackTrace) {
              Utils().showToast(error.toString());
            });
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: const Center(
        child: Text("HomePage",style: TextStyle(
          fontSize: 24
        ),),
      ),
    );
  }
}
