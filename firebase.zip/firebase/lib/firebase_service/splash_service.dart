import 'dart:async';

import 'package:firebase/ui/home_page.dart';
import 'package:firebase/ui/sign_in.dart';
import 'package:firebase/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SplashService{
  void isLogin(BuildContext context){
    final user = Utils.auth.currentUser;
    if(user != null){
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=> const HomePage()));
      });
    }else{
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=> const SignInScreen()));
      });    }

  }
}